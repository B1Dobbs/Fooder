Thanks for your appreciation!

This font is made for personal use, if you want to have commercial version you can get it here:

https://creativemarket.com/ekobimantara/3629922-Malvie-Fun-and-Casual-Font

Or you can contact us directly:
ekobimantarafonts@gmail.com

Best regards
